# (a) Import dataset
setwd("C:\\Users\\ASUS\\Desktop\\IT24101291")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
fix(Delivery_Times)
attach(Delivery_Times)

# (b) Histogram with 9 classes
x <- Delivery_Times[[1]]   # or use backticks for column name
breaks <- seq(20, 70, by = 5)

hist(x, breaks = breaks, right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     col = "lightblue", border = "black")

# (d) Cumulative Frequency Polygon (Ogive)
hist_data <- hist(x, breaks = breaks, right = FALSE, plot = FALSE)
cum_freq <- cumsum(hist_data$counts)

plot(breaks[-1], cum_freq, type = "o", 
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "blue")

