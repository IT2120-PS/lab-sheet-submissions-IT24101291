# Q1
setwd("C:/Users/it24101291/Desktop/IT24101291") 
branch_data <- read.table("Exercise.txt", header=TRUE, sep=",")   # Import CSV-like data
head(branch_data)   # Show first few rows
attach(branch_data) # Attach dataframe for easy column access


# Q2
branch_data$Branch <- as.factor(branch_data$Branch)
# Check structure of dataset after conversion
str(branch_data)
# Check types individually
class(branch_data$Branch)         # Factor -> categorical (nominal)
class(branch_data$Sales_X1)       # Numeric (ratio)
class(branch_data$Advertising_X2) # Numeric (ratio)
class(branch_data$Years_X3)       # Numeric (ratio)



# Q3
boxplot(Sales_X1, main="Boxplot of Sales", col="lightblue")   # Boxplot for sales

# Q4
fivenum(Advertising_X2)   # Five number summary
IQR(Advertising_X2)       # Interquartile Range

# Q5
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)        # First quartile
  q3 <- quantile(x, 0.75)        # Third quartile
  iqr <- q3 - q1                 # Interquartile range
  lower <- q1 - 1.5 * iqr        # Lower bound
  upper <- q3 + 1.5 * iqr        # Upper bound
  outliers <- x[x < lower | x > upper]   # Values outside bounds
  return(outliers)               # Return outliers
}

find_outliers(Years_X3)   # Check outliers in Years